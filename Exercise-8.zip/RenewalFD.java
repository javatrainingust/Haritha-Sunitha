package com.training.account.model;

import com.training.account.model.FDAccount;
import com.training.account.model.Renewal;

public class RenewalFD {
	
	public static void main(String args[]) {
		
		Renewal ren = new FDAccount();
		
		ren.upautoRenewal(4);
		
	}

}
