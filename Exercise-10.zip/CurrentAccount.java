/**
 * CurrentAccount
 * 
 * CurrentAccount extends Account class
 *
 * 30/9/2020
 * 
*/


package com.training.account.model;

/**
 * class to perform account operation of CurrentAccount
*/

public class CurrentAccount extends Account{

	
	private int overDraftLimit;

	/*
	* CurrentAccount Default Constructor
	*/
	publicCurrentAccount(){
		System.out.println("No Arg Constructor");
	}

	public int getOverDraftLimit() {
		return overDraftLimit;
	}

	public void setOverDraftLimit(int overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}
}
