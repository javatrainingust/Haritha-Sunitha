/***
 * class: StreamArrayList
 * 
 * Description: Class used to implement Stream ArrayList 
 *
 * Date:09.10.2020
 * 
*/
package com.training.account.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/***
 * StreamDemoArrayList class used to implement Stream ArrayList
 */
public class StreamArrayList {
	/**
	 * main method
	**/
	public static void main(String[] args) {
		List<String> names = new ArrayList<String>();

		names.add("Suman");
		names.add("Sundhar");
		names.add("Viji");
		names.add("Aruthra");
		names.add("Athvi");

		Stream<String> nmStream = names.stream();

		long count = nmStream.count();

		System.out.println("Total Names: " + count);
	}

}
