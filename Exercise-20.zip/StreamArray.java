/**
 *Class Name  : StreamArray
 * 
 *Description : Implementation of the StreamArray 
 *
 *Date of Creation: 09-10-2020
 *
**/

package com.training.account.stream;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.stream.Stream;

/**
 * 
 * Class to implement the Stream Array
 *
 */

public class StreamArray {
	
public static void main(String[] args) {
		
		String[] str = {"Haritha","Hareesh","Anju","Suraj","Nayana"};
		
		/**stream the array**/
		Stream<String> names = Arrays.stream(str);
		
		long numberOfString = names.count();
		
		System.out.println("Number of String Objects are: "+numberOfString);

	}

}


