/**
 * Class: SBAccountDAOImpl
 * 
 * Description: SBAccountDAOImpl is an implementation class for SBAccountDAO
 * 
 * Date: 06/10/2020
**/
package com.training.account.dataaccess;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.account.SBAccount;

/**
 * 
 * SBAccountDAOImpl class implements SBAccountDAO
 * 
 **/

public class SBAccountDAOImpl implements SBAccountDAO {
	List<SBAccount> sBAcntList;

	 public SBAccountDAOImpl() {
		 sBAcntList=new ArrayList<SBAccount>();	
		 SBAccount sa1=new SBAccount(100,"Haritha",1500);
		 SBAccount sa2=new SBAccount(101,"Hareesh",2000);
		 SBAccount sa3=new SBAccount(102,"Mohan",2500);
		 SBAccount sa4=new SBAccount(103,"Sunitha",3000);
		 sBAcntList.add(sa1);
		 sBAcntList.add(sa2);
		 sBAcntList.add(sa3);
		 sBAcntList.add(sa4);
	 }
	 /** getAllSBAccounts method is for getting all the SBAccount **/
		@Override
		public List<SBAccount> getAllSBAccounts() {
			
			return sBAcntList;
		}
		/** getSBAccountByAccountNo method is for getting a particular SBAccount **/

		@Override
		public SBAccount getSBAccountByAccountNo(int accountNumber) {
			SBAccount sBAccount=null;
			Iterator<SBAccount> iterator=cAcntList.iterator();
			while (iterator.hasNext()) {
				SBAccount SA = (SBAccount) iterator.next();
				if (SA.getAccountNo()==accountNumber) {
					sBAccount= SA;
					
				}
				
			}
			return sBAccount;
		}
		/** deleteSBAccount method is for deleting a particular SBAccount using account number**/
		
		@Override
		public void deleteSBAccount(int accountNumber) {
			
			SBAccount sBAccount=null;
			for (int i = 0; i < sBAcntList.size(); i++) {
				sBAccount = (SBAccount)  sBAcntList.get(i);
				if (sBAccount.getAccountNo()==accountNumber) {
					sBAcntList.remove(i);
				}	
		}

		}



}
	 
