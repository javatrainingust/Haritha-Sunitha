/**
 * Class: LoanAccountDAOImplTest
 *
 * Description: LoanAccountDAOImplTest is the class for JUnit testing
 *
 * Date: 06/10/2020
**/

package com.training.account.dataaccess;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import com.training.account.LoanAccount;
/**
 * 
 * LoanAccountDAOImplTest is the class for JUnit testing
 * 
 **/

public class LoanAccountDAOImplTest {
	
	List expectedList;
	/**
	 * Constructor for LoanAccountDAOImplTest
	 */
	public LoanAccountDAOImplTest()

	{
		expectedList = new ArrayList<LoanAccount>();
		LoanAccount la1=new LoanAccount(100,"Haritha",1500);
		LoanAccount la2=new LoanAccount(101,"Hareesh",2000);
		LoanAccount la3=new LoanAccount(102,"Mohan",2500);
		LoanAccount la4=new LoanAccount(103,"Sunitha",3000);
		expectedList.add(la1);
		expectedList.add(la2);
		expectedList.add(la3);
		expectedList.add(la4);
	}
 /**
 * To display all loan accounts
 **/
	
	@Test

	public void testGetAllLoanAccounts() {

		LoanAccountDAOImpl loanAccountDAOImpl = new LoanAccountDAOImpl();

		List actualList = loanAccountDAOImpl.getAllLoanAccounts();

		assertEquals(expectedList.size(), actualList.size());

	}
	
	@Test
	
	/** To Find an Account Holder Name using Account Number**/

	public void testGetLoanAccountsByAccountNo() {

		String expectedValue = "Sunitha";

		LoanAccountDAOImpl loanAccountDAOImpl = new LoanAccountDAOImpl();

		LoanAccount actualValue = loanAccountDAOImpl.getLoanAccountByAccountNo(103);

		assertEquals(expectedValue, actualValue.getAccountHolderName());

	}
	

}
