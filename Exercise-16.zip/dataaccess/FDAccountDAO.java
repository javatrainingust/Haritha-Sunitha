/**
 * Interface: FDAccountDAO
 *
 * Description: This FDAccountDAO interface contains the methods for class implementation
 *
 * Date:06/10/2020
**/

package com.training.account.dataaccess;

import java.util.List;
import com.training.account.FDAccount;
/**
* 
This interface interface contains the methods for class implementation
* 
**/

public interface FDAccountDAO {
	
	public List<FDAccount> getAllFDAccounts();

	public FDAccount getFDAccountByAccountNo(int accountNumber);

	public void deleteFDAccount(int accountNumber);

}
