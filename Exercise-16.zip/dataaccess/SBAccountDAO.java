/**
 * Interface: SBAccountDAO
 *
 * Description: This SBAccountDAO interface contains the methods for class implementation
 *
 * Date:06/10/2020
**/

package com.training.account.dataaccess;

import java.util.List;

import com.training.account.SBAccount;
/**
* 
This interface interface contains the methods for class implementation
* 
**/

public interface SBAccountDAO {

	public List<SBAccount> getAllSBAccounts();

	public SBAccount getSBAccountByAccountNo(int accountNumber);

	public void deleteSBAccount(int accountNumber);
}
