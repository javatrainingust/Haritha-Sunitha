/**
 * Interface: LoanAccountDAO
 *
 * Description: This LoanAccountDAO interface contains the methods for class implementation
 *
 * Date:06/10/2020
**/

package com.training.account.dataaccess;

import java.util.List;
import com.training.account.LoanAccount;
/**
* 
This interface contains the methods for class implementation
* 
**/

public interface LoanAccountDAO {
	
	public List<LoanAccount> getAllLoanAccounts();

	public LoanAccount getLoanAccountByAccountNo(int accountNumber);

	public void deleteLoanAccount(int accountNumber);

}
