/**
 * Class: FDAccountDAOImpl
 * 
 * Description: FDAccountDAOImpl is an implementation class for FDAccountDAO
 * 
 * Date: 06/10/2020
**/
package com.training.account.dataaccess;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.account.FDAccount;
import com.training.account.FDAccount;
import com.training.account.FDAccount;

/**
 * 
 * FDAccounttDAOImpl class implements FDAccountDAO
 * 
 **/

public class FDAccountDAOImpl implements FDAccountDAO {
	List<FDAccount> fDAcntList;

	 public FDAccountDAOImpl() {
		 fDAcntList=new ArrayList<FDAccount>();	
		 FDAccount fd1=new FDAccount(100,"Haritha",1500);
		 FDAccount fd2=new FDAccount(101,"Hareesh",2000);
		 FDAccount fd3=new FDAccount(102,"Mohan",2500);
		 FDAccount fd4=new FDAccount(103,"Sunitha",3000);
		 fDAcntList.add(fd1);
		 fDAcntList.add(fd2);
		 fDAcntList.add(fd3);
		 fDAcntList.add(fd4);

	 }
	 
	 /** getAllFDAccounts method is for getting all the Fixed Accounts**/
		@Override
		public List<FDAccount> getAllFDAccounts() {
			
			return fDAcntList;
		}
		/** getFDAccountByAccountNo method is for getting a particular Fixed Account**/

		@Override
		public FDAccount getFDAccountByAccountNo(int accountNumber) {
			FDAccount fDAccount=null;
			Iterator<FDAccount> iterator=fDAcntList.iterator();
			while (iterator.hasNext()) {
				FDAccount FD = (FDAccount) iterator.next();
				if (FD.getAccountNo()==accountNumber) {
					fdAccount= FD;
					
				}
				
			}
			return fDAccount;
		}
		/** deleteFDAccount method is for deleting a particular Fixed Account using account number*/

		@Override
		public void deleteFDAccount(int accountNumber) {
			
			FDAccount fdAccount=null;
			for (int i = 0; i < fDAcntList.size(); i++) {
				fdAccount = (FDAccount)  fDAcntList.get(i);
				if (FDAccount.getAccountNo()==accountNumber) {
					fDAcntList.remove(i);
				}	
		}

		}

}
