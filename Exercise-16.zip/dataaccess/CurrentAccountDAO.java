/**
 * Interface: CurrentAccountDAO
 *
 * Description: This CurrentAccountDAO interface contains the methods for class implementation
 *
 * Date:06/10/2020
**/

package com.training.account.dataaccess;

import java.util.List;

import com.training.account.CurrentAccount;
/**
* 
This interface interface contains the methods for class implementation
* 
**/
public interface CurrentAccountDAO {

	public List<CurrentAccount> getAllCurrentAccounts();

	public CurrentAccount getCurrentAccountByAccountNo(int accountNumber);

	public void deleteCurrentAccount(int accountNumber);
	
}
