/***
 * class: CurrentAccountService
 * 
 * Description: Class used to implement CurrentAccountService
 *
 * Date:06.10.2020
 * 
*/

package com.training.account.service;

import java.util.Iterator;
import java.util.List;

import com.training.account.dataaccess.CurrentAccountDAO;
import com.training.account.dataaccess.CurrentAccountDAOImpl;
import com.training.account.CurrentAccount;

/**
 * Class used to implement CurrentAccountService
 * 
**/

public class CurrentAccountService {
	CurrentAccountDAO currentAccountDAOImpl;

	public CurrentAccountService() {

		currentAccountDAOImpl = new CurrentAccountDAOImpl();
		
		
		/** Display all accounts**/
		public List<CurrentAccount> getAllCurrentAccounts() {

			List currentAccountList = currentAccountDAOImpl.getAllCurrentAccounts();
			Iterator<CurrentAccount> iterator = currentAccountList.iterator();

			while (iterator.hasNext()) {

				CurrentAccount ca = iterator.next();

				System.out.println("Account Number: = " + ca.getAccountNo());
				System.out.println("Accont Holder Name: = " + ca.getAccountHolderName());
				System.out.println("Available Account Balance: =" + ca.getBalance());

			}

			return currentAccountList;

		}
		/** display particular CurrentAccount using account number**/
		public CurrentAccount getCurrentAccountByAccountNo(int accountNumber) {

			CurrentAccount ca = currentAccountDAOImpl.getCurrentAccountByAccountNo(accountNo);

			System.out.println("Account Number: = " + ca.getAccountNo());
			System.out.println("Accont Holder Name: = " + ca.getAccountHolderName());
			System.out.println("Available Account Balance: =" + ca.getBalance());

			return ca;

		}
		/* deleteCurrentAccount method is for deleting a particular  CurrentAccount*/
		public void deleteCurrentAccount(int accountNumber) {

			currentAccountDAOImpl.deleteCurrentAccount(accountNumber);

		}

	
}
