/**
 * class: CurrentAccountRetrieval
 * 
 * Description: CurrentAccountRetrieval class used to print specific accounts for CurrentAccount
 *
 * Date:06.10.2020
 * 
**/

package com.training.account.service;

/** CurrentAccountRetrieval class used to print specific accounts for CurrentAccount **/

public class CurrentAccountRetrieval  {
	
	public static void main(String[] args) {
		 CurrentAccountService service =  new  CurrentAccountService();
		
		
		/** Retrieving all CurrentAccounts **/
		
		service.getAllCurrentAccounts();
		
		service.getCurrentAccountByAccountNo(100);

	}

	
}
