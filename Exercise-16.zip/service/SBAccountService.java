/***
 * class: SBAccountService
 * 
 * Description: Class used to implement SBAccountService
 *
 * Date:06.10.2020
 * 
*/

package com.training.account.service;

import java.util.Iterator;
import java.util.List;

import com.training.account.dataaccess.SBAccountDAO;
import com.training.account.dataaccess.SBAccountDAOImpl;
import com.training.account.SBAccount;

/**
 * Class used to implement SBAccountService
 * 
**/

public class SBAccountService {
	SBAccountDAO sBAccountDAOImpl;

	public SBAccountService() {

		sBAccountDAOImpl = new SBAccountDAOImpl();
		
		
		/** Display all accounts**/
		public List<SBAccount> getAllSBAccounts() {

			List sBAccountList = sBAccountDAOImpl.getAllSBAccounts();
			Iterator<SBAccount> iterator = sBAccountList.iterator();

			while (iterator.hasNext()) {

				SBAccount sa = iterator.next();

				System.out.println("Account Number: = " + sa.getAccountNo());
				System.out.println("Accont Holder Name: = " + sa.getAccountHolderName());
				System.out.println("Balance: =" + sa.getBalance());

			}

			return sBAccountList;

		}
		/** display particular SBAccount using account number**/
		public SBAccount getSBAccountByAccountNo(int accountNumber) {

			SBAccount sa = sBAccountDAOImpl.getSBAccountByAccountNo(accountNo);

			System.out.println("Account Number: = " + sa.getAccountNo());
			System.out.println("Accont Holder Name: = " + sa.getAccountHolderName());
			System.out.println("Balance: =" + sa.getBalance());

			return sa;

		}
		/* deleteSBAccount method is for deleting a particular  SBAccount*/
		public void deleteSBAccount(int accountNumber) {

			sBAccountDAOImpl.deleteSBAccount(accountNumber);

		}

	
}
