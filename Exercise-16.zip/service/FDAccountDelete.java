/***
 * class: FDAccountDelete
 * 
 * Description: FDAccountDelete class used to delete and print for FDAccount
 *
 * Date:06.10.2020
 * 
 **/

package com.training.account.service;

public class FDAccountDelete {
	
	public static void main(String[] args) {
		FDAccountService service =  new FDAccountService();
		
		System.out.println("FDAccount retrieved successfully");
		
		service.getAllFDAccounts();
				
		service.deleteFDAccount(100);
		
		System.out.println("----------------------------");
		System.out.println("After deletion");
		
		service.getAllFDAccounts();
	}

}
