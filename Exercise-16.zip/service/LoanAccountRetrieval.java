/**
 * class: LoanAccountRetrieval
 * 
 * Description: LoanAccountRetrieval class used to print specific accounts for LoanAccount
 *
 * Date:06.10.2020
 * 
**/

package com.training.account.service;

/** LoanAccountRetrieval class used to print specific accounts for LoanAccount **/

public class LoanAccountRetrieval  {
	
	public static void main(String[] args) {
		 LoanAccountService service =  new  LoanAccountService();
		
		
		/** Retrieving all LoanAccounts **/
		
		service.getAllLoanAccounts();
		
		service.getLoanAccountByAccountNo(100);

	}

	
}
