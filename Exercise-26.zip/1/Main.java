/***
 * ClassName : Main
 * 
 * Description:Main contains main method
 * 
 * Date: 12-10-2020
 * 
 */

package com.training.account.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/***
 * 
 *Class contain main method 
 *
 */


public class Main {

	/**
	 * 
	 * Main method
	 *
	 * calling bean method 
	 * 
	 **/
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*Path object for xml*/
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		
		Organiser org =  context.getBean("organiser",Organiser.class);
		
		org.sayGreeting();
	}

}
