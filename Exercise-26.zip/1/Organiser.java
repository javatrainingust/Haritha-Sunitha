/***
 *ClassName:Orginiser
 *
 *
 *Description:Organiser Pojo class 
 *
 * Date-12-10-2020
 */
package com.training.account.spring;

/***
 * 
 * Organiser class contain method name sayGreeting for printing the display
 *
 */


public class Organiser {

	/***
	 * Method used for printng the message
	**/
	
	public void sayGreeting()
	{
		System.out.println("Welcome....");
		
	}
}
