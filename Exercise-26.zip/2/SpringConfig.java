/***
 * ClassName:SpringConfiguration
 * 
 * 
 * Date:13-10-2020
 * 
 */



package com.training.account.spring2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/***
 * 
 * Class for SpringConfiguration code
 * 
 */

@Configuration
public class SpringConfig {
	
	/****
	 * Creating bean object
	 * 
	 *  
	 */
	
	@Bean(name="instrumentlist")
	public Instrumentlist getInstrumentList()
	{
		System.out.println("Hello WOrld");
		Instrumentlist i = new Instrumentlist();
		
		i.setSaxaphonee(getSaxphone());
		
		return i;
		
		
	}

	/***
	 * 
	 * Creating bean object 
	 * 
	 */
	
	@Bean
	public Saxaphone getSaxphone()
	{

		System.out.println("Hello worlddd");
		Saxaphone sp = new Saxaphone();
		
		return sp;
		
	}
}
