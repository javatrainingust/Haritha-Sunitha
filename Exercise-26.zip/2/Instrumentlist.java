/***
 * ClassName : Instrumentlist
 * 
 * Description  : pojo Class for instrumentlist
 * 
 * 
 * Date -12-10-2020
 */


package com.training.account.spring2;

/**
 * 
 * Class Implementing performer interface and contain perform fuction
 * 
 */

public class Instrumentlist implements Performer {

	Saxaphone sp;

	public Saxaphone getSaxaphonee() {
		return sp;
	}

	public void setSaxaphonee(Saxaphone saxaphonee) {
		this.sp = saxaphonee;
	}

	/**
	 * Implemented perform method definition calling saxaphone implemented method play
	 *  
	 *  Implemented from Instrument
	 */
	
	public void perform()
	{
		/*play Method call in Saxsaphone */
		sp.play();
		
	
	}
}
