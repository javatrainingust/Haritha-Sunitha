/***
 * ClassName:PerformanceDemo
 * 
 * Description: Execution for class Instrumentalist
 * 
 * Date - 12-10-2020
 */

package com.training.account.spring2;

import javax.naming.Context;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/***
 * 
 * Class: PerformanceDemo
 *
 */

public class PerformanceDemo {

	
	/***
	 * 
	 * Main method  for instrumentlist
	 **/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
AnnotationConfigApplicationContext annotationConfigApplicationContext = new AnnotationConfigApplicationContext(SpringConfiguration.class);
		
		Instrumentlist i = annotationConfigApplicationContext.getBean("Instrumentlist",Instrumentlist.class);
		
		i.perform();
	}

}
