/**
 * class: Stream2
 * 
 * Description: Class used to implement Streaming Array sorting
 *
 * Date:09.10.2020
 * 
**/

package com.training.account.stream;
import java.util.stream.Stream;
/**
 *  Stream2 class used to implement Streaming Array sorting
 * 
**/
public class Stream2 {
	/**
	 * main method
	**/
	public static void main(String[] args) {
		
		Stream<String> sortedStream = Stream.of("Haritha","Hareesh","Anju", "Arun","Suraj").sorted();
		
		sortedStream.forEach((e)->System.out.println(e));

	}

}
