/***
 * class: Stream3
 * 
 * Description: Class used to implement Streaming Array sorting
 *
 * Date:09.10.2020
 * 
*/

package com.training.account.stream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
/***
 * Stream3 class used to implement Streaming Array sorting
 * 
*/
public class Stream3 {
	/**
	 * main method
	**/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List cats = new ArrayList<Cat>();
		Cat c1=new Cat("Popy", 1);
		Cat c2=new Cat("Betty", 2);
		Cat c3=new Cat("Chikku", 3);
		Cat c4=new Cat("Puma", 4);
		cats.add(c2);
		cats.add(c1);
		cats.add(c3);
		cats.add(c4);
		
		Stream<Cat> stream = cats.stream();
		
		Stream<Cat> sortedCatStream = stream.sorted();
		
		sortedCatStream.forEach((e)->System.out.println(e));
		
		

	}
}
