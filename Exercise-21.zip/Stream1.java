/***
 * class: Stream1
 * 
 * Description: Class used to implement Streaming Array 
 *
 * Date:09.10.2020
 * 
*/
package com.training.account.stream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
/**
 * Stream1 class used to implement Streaming Array 
 * 
**/
public class Stream1 {
	/**
	 * main method
	 * */
public static void main(String[] args) {
	Integer[] numbers = {1,2,3,4,5,6,7,8,9};
		
		
	Stream<Integer> nStream = Arrays.stream(numbers);
		long result = nStream.map((n)->(n*n)).filter((i)->i>10).count();
		
		System.out.println("Values greater than 10: "+result);
		

	}

}
