package com. training.account.service;

import com.training.account.model.Account;
import com.training.account.model.CurrentAccount;
import com.training.account.model.FDAccount;
import com.training.account.model.LoanAccount;
import com.training.account.Util.InterestCal;

public class Accountdetails {

	public static void main(String args[]) {
		
		Account Acnt=new Account();
		
		Acnt.setAccountnumber(102879);
		Acnt.setName("Haritha Sunitha");
		Acnt.setbalance(12000);
		
		Acnt.withdrawMoney(1000);
		Acnt.CalculateInterest(Acnt.getAmount());
		

	System.out.println("Name is "+Acnt.getName());
	System.out.println("Accountnumber is "+Acnt.getAccountnumber());
	
	
      FDAccount FD=new FDAccount();
      
      FD.setAccountnumber(102879);
      FD.setName("Haritha Sunitha");
      FD.setAmount(1200);
      FD.setTenure(10);
      FD.updateFDAccounttype("yes");
      FD.loanOutBalance(FD.getAmount());
      FD.CalculateInterest(FD.getAmount());
      
      CurrentAccount CA= new CurrentAccount();
      
      CA.setAccountnumber(123456);
      CA.setName("Hareesh");
      CA.setAmount(1500);
      CA.setOverDraftLimit(CA.getOverDraftLimit()*3);
      System.out.println("OverDraftLimit"+CA.getOverDraftLimit());
      CA.loanOutBalance(FD.getAmount());
      
      LoanAccount LA=new LoanAccount();
      
      LA.setAccountnumber(789456);
      LA.setName("Arun");
      LA.setAmount(2000);
      LA.loanOutBalance(LA.getAmount());
      LA.setTenure(12);
      LA.EmiCalulate(CA.getAmount());    
      
}
}
