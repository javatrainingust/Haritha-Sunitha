/***
 * ClassName:Main
 * 
 * Description:Main method for Organiser
 * 
 * Date - 12-10-2020
 * 
 */

package com.training.account.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;


/***
 * 
 *Main class contains the main method 
 *
 */



public class Main {

	
	/**
	 * Getting the xml config path
	 * 
	 * Creating bean object 
	 * 
	 **/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		Organiser org =  context.getBean("organiser",Organiser.class);
		
		org.sayGreeting();

	}

}
