/***
 * ClassName : Main
 * 
 * Description:Main contains main method
 * 
 * Date: 12-10-2020
 * 
 */





package com.training.account.spring2;

import org.springframework.aop.interceptor.ConcurrencyThrottleInterceptor;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/***
 * 
 *Class contain main method 
 *
 */


public class Main {

	/**
	 * 
	 * Main method
	 *
	 * calling bean method 
	 * 
	 **/
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*Path object for xml*/
		
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("singerContext.xml");

		Singer s = applicationContext.getBean("singer",Singer.class);
		
		s.perform();
	}

}
