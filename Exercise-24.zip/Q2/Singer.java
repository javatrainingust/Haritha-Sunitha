/***
 * ClassName: Singer
 * 
 * Description : pojo class for Singer
 * 
 * 
 * Date-12-10-2020
 * 
 */


package com.training.account.spring2;

/***
 *
 *Implements perform interface
 * 
 */


public class Singer implements Perform {
	
	
	String singerName;
	
	
	/***
	 * 
	 *parameterized constructor for name initilisation 
	 * 
	 */
	public Singer(String Name) {
	
	singerName = Name;
	
	}


	/***
	 * 
	 *  Override perform method 
	 *  
	 */
	public void perform() {
		
		System.out.println("The Contestant name is:  "+singerName);
		
	}
	
	
	

}
