/***
 * InterfaceName:Perform
 * 
 * Description:Perform Interface for perform an operation
 * 
 * Date:12-10-2020
 * 
 */
package com.training.account.spring2;
/***
 * 
 * Implemented by Singer Class which contain one method and can be implemented .
 * 
 * 
 */

public interface Perform {
/* Method declaration*/
	
	public void perform();
}
