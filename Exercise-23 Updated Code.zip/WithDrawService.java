package com.training.account.service;

import com.training.account.InsufficentBalException;
import com.training.account.SBAccount;

public class WithDrawService {
	
	public static void main(String[] args) {
		
		SBAccount sb = new SBAccount(100,"Haritha",1000);
		
		try {
			sb.withdrawMoney(25000);
		} 
		catch (InsufficentBalException i) {
			
			System.out.println("Exception: " +i);
		}

}

}
