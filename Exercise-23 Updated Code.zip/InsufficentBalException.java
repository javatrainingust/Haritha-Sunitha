/**
 * Classname:InsufficentBalException
 * 
 * Description: This class extends Exception
 * 
 * Date:07-10-2020
 */

package com.training.account;

/** Description: This class extends Exception**/

public class InsufficentBalException extends Exception {
	String toWithdrawMoney;

	public InsufficentBalException(String string) {
		super();
		this.toWithdrawMoney = string;
	}

	@Override
	public String toString() {
		return "No sufficient balance to withdraw " + toWithdrawMoney;
	}

}
