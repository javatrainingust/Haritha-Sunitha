/**
 * Classname:SBAccount
 * 
 * Description:Sub class for Account class.
 * 
 * Date:30-09-2020
 * */

package com.training.account;

import com.training.util.InterestCal;

/*
 * SBAccount class is the subclass of Account
 */
public class SBAccount extends Account implements Comparable<SBAccount>{
	
	private int Accountnumber;
	private String Name;

   /*
    * Parameterized Constructor
    */
	public SBAccount(int accountNumber, String name,int amount) {
       super(accountNumber,name,amount);
		//this.Accountnumber = accountNumber;
		//this.Name = name;
       System.out.println(accountNumber);
	}

	/*
	 * Default Constructor
	 */
	public SBAccount() {
		// TODO Auto-generated constructor stub
	}

 public void withdrawMoney(int amount)throws InsufficentBalException {
	 
		System.out.println("Withdraw Amount:"+getAmount());
		if(getBalance()>getAmount()) {
			setBalance(getBalance()-getAmount());
			System.out.println("Balance:"+getBalance());
		}
		else {
			
			throw new InsufficentBalException(getAmount());
		//System.out.println("No sufficient amount");
		}
	}

	/*
	 * To calculate the Interest
	 */
	public void calculateInterest(float Amt, InterestCal cal)
	{
		System.out.println(""+Amt);
		ic.sBAccount(Amt,5,.05f);
		
	}

	@Override
	public int compareTo(SBAccount sBAccount) {
		// TODO Auto-generated method stub
		return 0;
	}
}
