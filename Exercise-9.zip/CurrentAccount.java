package com.training.account.model;

public class CurrentAccount extends Account{

	private int overDraftLimit;

	publicCurrentAccount(){
		System.out.println("No Arg Constructor");
	}

	public int getOverDraftLimit() {
		return overDraftLimit;
	}

	public void setOverDraftLimit(int overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}
}
