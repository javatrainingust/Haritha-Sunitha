/**
 * ClassName: SignUpServlet
 * 
 * Description: Class SignUpServlet extends HttpServlet
 * 
 * Date: 14/10/2020
 */
package com.training.account.design;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation 
 */
@WebServlet("/SignUpServlet")
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
       SignUp login = new SignUp();
		
       login.setUserId(request.getParameter("id"));
       login.setUserName(request.getParameter("name"));
       login.setPassword(request.getParameter("pass"));
       login.setConfirmPassword(request.getParameter("cpass"));

		request.setAttribute("key", login);
		request.getRequestDispatcher("confirm.jsp").forward(request,response);
		
	}

}
