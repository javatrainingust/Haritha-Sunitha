/***
 * InterfaceName:Instrument
 * 
 * Description:instrument interface with one method declaration
 * 
 * Date-12-10-2020
 */



package com.training.account.spring2;

/***
 *Instrument interface for method declaration 
 *
 **/


public interface Instrument {
	
	/*Play method declaration*/
	
	public void play();

}
