/***
 * ClassName : Instrumentlist
 * 
 * Description  : pojo Class for instrumentlist
 * 
 * 
 * Date -12-10-2020
 */


package com.training.account.spring2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 
 * Class Implementing performer interface and contain perform fuction
 * 
 */

@Component("instrumentlist")

public class Instrumentlist implements Performer {

	@Autowired
	Saxaphone sp;


	public void perform()
	{
		/*play Method call in Saxsaphone */
		sp.play();
		
	
	}
}
