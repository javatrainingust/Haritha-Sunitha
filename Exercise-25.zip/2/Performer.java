/**
 * ClassName: Performer
 * 
 * Description: PerformerInterface
 * 
 * Date:12-10-2020
 * 
 */


package com.training.account.spring2;
/***
 * 
 * Interface for declaring a method perform.
 */


public interface Performer {

	/*perform method declaration*/
	public void perform();
}
