/***
 * ClassName:PerformanceDemo
 * 
 * Description: Execution for class Instrumentalist
 * 
 * Date - 12-10-2020
 */

package com.training.account.spring2;

import javax.naming.Context;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/***
 * 
 * Class: PerformanceDemo
 *
 */

public class PerformanceDemo {

	
	/***
	 * 
	 * Main method  for instrumentlist
	 **/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("musicContext.xml");
		
		Instrumentlist i = applicationContext.getBean("instrumentlist",Instrumentlist.class);
		
		i.perform();

	}

}
