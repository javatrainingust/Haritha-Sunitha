/**
 * Class: FDAccountDAOImplTest
 *
 * Description: FDAccountDAOImplTest is the class for JUnit testing
 *
 * Date: 06/10/2020
**/

package com.training.account.dataaccess;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import com.training.account.FDAccount;
import com.training.account.FDAccount;
import com.training.account.FDAccount;
/**
 * 
 * FDAccountDAOImplTest is the class for JUnit testing
 * 
 **/
public class FDAccountDAOImplTest {
	List expectedList;
	/**
	 * Constructor for FDAccountDAOImplTest 
	 */
	public FDAccountDAOImplTest ()

	{
		expectedList = new ArrayList<FDAccount>();
		FDAccount fd1=new FDAccount(100,"Haritha",1500);
		FDAccount fd2=new FDAccount(101,"Hareesh",2000);
		FDAccount fd3=new FDAccount(102,"Mohan",2500);
		FDAccount fd4=new FDAccount(103,"Sunitha",3000);
		expectedList.add(fd1);
		expectedList.add(fd2);
		expectedList.add(fd3);
		expectedList.add(fd4);
	}
	
	/**
	* To display all fixed accounts
	*/
	@Test

	public void testGetAllFDAccounts() {

		FDAccountDAOImpl fDAccountDAOImpl = new FDAccountDAOImpl();

		List actualList = fDAccountDAOImpl.getAllFDAccounts();

		assertEquals(expectedList.size(), actualList.size());

	}
	@Test
	
	/** To Find an Account Holder Name using Account Number**/

	public void testGetFDAccountByAccountNo() {

		String expectedValue = "Sunitha";

		FDAccountDAOImpl fDAccountDAOImpl = new FDAccountDAOImpl();

		FDAccount actualValue = fDAccountDAOImpl.getFDAccountByAccountNo(103);

		assertEquals(expectedValue, actualValue.getAccountHolderName());

	}
	
	@Test
	
	/** Delete an account by Account Number**/
	
	public void testDeleteFDAccount() {

		FDAccountDAOImpl  fDAccountDAOImpl  = new FDAccountDAOImpl();

		fDAccountDAOImpl.deleteFDAccount(100);

		List actualValue = fDAccountDAOImpl.getAllFDAccounts();

		assertEquals(expectedList.size() - 1, actualValue.size());

	}

}
