/**
 * Class: CurrentAccountDAOImpl
 * 
 * Description: CurrentAccountDAOImpl is an implementation class for CurrentAccountDAO
 * 
 * Date: 06/10/2020
**/
package com.training.account.dataaccess;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.account.CurrentAccount;

/**
 * 
 * CurrentAccountDAOImpl class implements CurrentAccountDAO
 * 
 **/

public class CurrentAccountDAOImpl implements CurrentAccountDAO {
	List<CurrentAccount> cAcntList;

	 public CurrentAccountDAOImpl() {
		 cAcntList=new ArrayList<CurrentAccount>();	
		 CurrentAccount ca1=new CurrentAccount(100,"Haritha",1500);
		 CurrentAccount ca2=new CurrentAccount(101,"Hareesh",2000);
		 CurrentAccount ca3=new CurrentAccount(102,"Mohan",2500);
		 CurrentAccount ca4=new CurrentAccount(103,"Sunitha",3000);
		 cAcntList.add(ca1);
		 cAcntList.add(ca2);
		 cAcntList.add(ca3);
		 cAcntList.add(ca4);

}
	 /** getAllCurrentAccounts method is for getting all the CurrentAccount **/
		@Override
		public List<CurrentAccount> getAllCurrentAccounts() {
			
			return cAcntList;
		}
		/** getCurrentAccountByAccountNo method is for getting a particular CurrentAccount **/

		@Override
		public CurrentAccount getCurrentAccountByAccountNo(int accountNumber) {
			CurrentAccount currentAccount=null;
			Iterator<CurrentAccount> iterator=cAcntList.iterator();
			while (iterator.hasNext()) {
				CurrentAccount CA = (CurrentAccount) iterator.next();
				if (CA.getAccountNumber()==accountNumber) {
					currentAccount= CA;
					
				}
				
			}
			return currentAccount;
		}
		/** deleteCurrentAccount method is for deleting a particular CurrentAccount using account number**/

		@Override
		public void deleteCurrentAccount(int accountNumber) {
			
			CurrentAccount currentAccount=null;
			for (int i = 0; i < cAcntList.size(); i++) {
				currentAccount = (CurrentAccount)  cAcntList.get(i);
				if (currentAccount.getAccountNumber()==accountNumber) {
					cAcntList.remove(i);
				}	
		}

		}

	}
