/**
 * Class: CurrentAccountDAOImplTest
 *
 * Description: CurrentAccountDAOImplTest is the class for JUnit testing
 *
 * Date: 06/10/2020
**/

package com.training.account.dataaccess;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import com.training.account.CurrentAccount;
/**
 * 
 * CurrentAccountDAOImplTest is the class for JUnit testing
 * 
 **/
public class CurrentAccountDAOImplTest {
	List expectedList;
	/**
	 * Constructor for CurrentAccountDAOImplTest
	 */
	public CurrentAccountDAOImplTest()

	{
		expectedList = new ArrayList<CurrentAccount>();
		CurrentAccount ca1 = new CurrentAccount(100, "Haritha", 1500);
		CurrentAccount ca2 = new CurrentAccount(101, "Hareesh", 2000);
		CurrentAccount ca3 = new CurrentAccount(102, "Mohan", 2500);
		CurrentAccount ca4 = new CurrentAccount(103, "Sunitha", 3000);
		expectedList.add(ca1);
		expectedList.add(ca2);
		expectedList.add(ca3);
		expectedList.add(ca4);
	}
 /**
 * To display all current accounts
 */
	@Test

	public void testGetAllCurrentAccounts() {

		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();

		List actualList = currentAccountDAOImpl.getAllCurrentAccounts();

		assertEquals(expectedList.size(), actualList.size());

	}

	@Test
	
	/** To Find an Account Holder Name using Account Number**/

	public void testGetCurrentAccountsByAccountNo() {

		String expectedValue = "Sunitha";

		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();

		CurrentAccount actualValue = currentAccountDAOImpl.getCurrentAccountByAccountNo(103);

		assertEquals(expectedValue, actualValue.getAccountHolderName());

	}

	@Test
	
	/** Delete an account by Account Number**/
	
	public void testDeleteCurrentAccount() {

		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();

		currentAccountDAOImpl.deleteCurrentAccount(100);

		List actualValue = currentAccountDAOImpl.getAllCurrentAccounts();

		assertEquals(expectedList.size() - 1, actualValue.size());

	}
}
