/**
 * Class: SBAccountDAOImplTest
 *
 * Description: SBAccountDAOImplTest is the class for JUnit testing
 *
 * Date: 06/10/2020
**/

package com.training.account.dataaccess;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import com.training.account.SBAccount;
/**
 * 
 * SBAccountDAOImplTest is the class for JUnit testing
 * 
 **/

public class SBAccountDAOImplTest {
	
	List expectedList;
	/**
	 * Constructor for SBAccountDAOImplTest
	 */
	public SBAccountDAOImplTest()

	{
		expectedList = new ArrayList<SBAccount>();
		SBAccount sa1=new SBAccount(100,"Haritha",1500);
		SBAccount sa2=new SBAccount(101,"Hareesh",2000);
		SBAccount sa3=new SBAccount(102,"Mohan",2500);
		SBAccount sa4=new SBAccount(103,"Sunitha",3000);
		expectedList.add(sa1);
		expectedList.add(sa2);
		expectedList.add(sa3);
		expectedList.add(sa4);
	}
 /**
 * To display all SBAccounts
 **/
	@Test

	public void testGetAllSBAccounts() {

		SBAccountDAOImpl sBAccountDAOImpl = new SBAccountDAOImpl();

		List actualList = sBAccountDAOImpl.getAllSBAccounts();

		assertEquals(expectedList.size(), actualList.size());

	}
	@Test
	
	/** To Find an Account Holder Name using Account Number**/

	public void testGetSBAccountsByAccountNo() {

		String expectedValue = "Sunitha";

		SBAccountDAOImpl sBAccountDAOImpl = new SBAccountDAOImpl();

		SBAccount actualValue = sBAccountDAOImpl.getSBAccountByAccountNo(103);

		assertEquals(expectedValue, actualValue.getAccountHolderName());

	}

	@Test
	
	/** Delete an account by Account Number**/
	
	public void testDeleteSBAccount() {

		SBAccountDAOImpl sBAccountDAOImpl = new SBAccountDAOImpl();

		sBAccountDAOImpl.deleteSBAccount(100);

		List actualValue = sBAccountDAOImpl.getAllSBAccounts();

		assertEquals(expectedList.size() - 1, actualValue.size());

	}

}
