/**
 * Class: LoanAccountDAOImpl
 * 
 * Description: LoanAccountDAOImpl is an implementation class for LoanAccountDAO
 * 
 * Date: 06/10/2020
**/

package com.training.account.dataaccess;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.account.LoanAccount;

/**
 * 
 * LoanAccountDAOImpl class implements LoanAccountDAO
 * 
 **/


public class LoanAccountDAOImpl implements LoanAccountDAO {
	
	List<LoanAccount> lAcntList;

	 public LoanAccountDAOImpl() {
		 lAcntList=new ArrayList<LoanAccount>();	
		 LoanAccount la1=new LoanAccount(100,"Haritha",1500);
		 LoanAccount la2=new LoanAccount(101,"Hareesh",2000);
		 LoanAccount la3=new LoanAccount(102,"Mohan",2500);
		 LoanAccount la4=new LoanAccount(103,"Sunitha",3000);
		 lAcntList.add(la1);
		 lAcntList.add(la2);
		 lAcntList.add(la3);
		 lAcntList.add(la4);

}
	 
	 /* getAllLoanAccounts method is for getting all the Loan Accounts*/
		@Override
		public List<LoanAccount> getAllLoanAccounts() {
			
			return lAcntList;
		}
		/* getLoanAccountByAccountNo method is for getting a particular LoanAccount*/

		@Override
		public LoanAccount getLoanAccountByAccountNo(int accountNumber) {
			LoanAccount loanAccount=null;
			Iterator<LoanAccount> iterator=lAcntList.iterator();
			while (iterator.hasNext()) {
				LoanAccount LA = (LoanAccount) iterator.next();
				if (LA.getAccountNumber()==accountNumber) {
					loanAccount= LA;
					
				}
				
			}
			return loanAccount;
		}
		/** deleteLoanAccount method is for deleting a particular LoanAccount using account number **/
		
		@Override
		public void deleteLoanAccount(int accountNumber) {
			
			LoanAccount loanAccount=null;
			for (int i = 0; i < lAcntList.size(); i++) {
				loanAccount = (LoanAccount)  lAcntList.get(i);
				if (loanAccount.getAccountNumber()==accountNumber) {
					lAcntList.remove(i);
				}	
		}

		}

	}

		
		

