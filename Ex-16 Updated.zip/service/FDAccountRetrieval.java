/**
 * class: FDAccountRetrieval
 * 
 * Description: FDAccountRetrieval class used to print specific accounts for FDAccount
 *
 * Date:06.10.2020
 * 
**/
package com.training.account.service;

/** FDAccountRetrieval class used to print specific accounts for FDAccount **/


public class FDAccountRetrieval {

	public static void main(String[] args) {
		 FDAccountService service =  new  FDAccountService();
		
		
		/** Retrieving all FDAccounts **/
		
		service.getAllFDAccounts();
		
		service.getFDAccountByAccountNo(100);

	}
	
}
