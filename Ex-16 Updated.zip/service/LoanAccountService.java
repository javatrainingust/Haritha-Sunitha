/***
 * class: LoanAccountService
 * 
 * Description: Class used to implement LoanAccountService
 *
 * Date:06.10.2020
 * 
*/

package com.training.account.service;

import java.util.Iterator;
import java.util.List;

import com.training.account.dataaccess.LoanAccountDAO;
import com.training.account.dataaccess.LoanAccountDAOImpl;
import com.training.account.LoanAccount;

/**
 * Class used to implement LoanAccountService
 * 
**/

public class LoanAccountService {
	LoanAccountDAO loanAccountDAOImpl;

	public LoanAccountService() {

		loanAccountDAOImpl = new LoanAccountDAOImpl();
	}
		
		
		/** Display all accounts**/
		public List<LoanAccount> getAllLoanAccounts() {

			List loanAccountList = loanAccountDAOImpl.getAllLoanAccounts();
			Iterator<LoanAccount> iterator = loanAccountList.iterator();

			while (iterator.hasNext()) {

				LoanAccount la = iterator.next();

				System.out.println("Account Number: = " + la.getAccountNumber());
				System.out.println("Accont Holder Name: = " + la.getAccountHolderName());
				System.out.println("Available Account Balance: =" + la.getBalance());

			}

			return loanAccountList;

		}
		/** display particular LoanAccount using account number**/
		public LoanAccount getLoanAccountByAccountNo(int accountNumber) {

			LoanAccount la = loanAccountDAOImpl.getLoanAccountByAccountNo(accountNumber);

			System.out.println("Account Number: = " + la.getAccountNumber());
			System.out.println("Accont Holder Name: = " + la.getAccountHolderName());
			System.out.println("EMI: =" + la.getEmi());
			System.out.println("Loan Amount: =" + la.getLoanOutStanding());
			

			return la;

		}
		/** deleteLoanAccount method is for deleting a particular  LoanAccount**/
		public void deleteLoanAccount(int accountNumber) {

			loanAccountDAOImpl.deleteLoanAccount(accountNumber);

		}

	
}
