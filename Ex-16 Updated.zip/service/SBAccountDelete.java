/***
 * class: SBAccountDelete
 * 
 * Description: SBAccountDelete class used to delete and print for SBAccountDelete
 *
 * Date:06.10.2020
 * 
 **/

package com.training.account.service;

public class SBAccountDelete {

	public static void main(String[] args) {
		SBAccountService service =  new SBAccountService();
		
		System.out.println("SBAccount retrieved successfully");
		
		service.getAllSBAccounts();
				
		service.deleteSBAccount(100);
		
		System.out.println("----------------------------");
		System.out.println("After deletion");
		
		service.getAllSBAccounts();
	}
}
