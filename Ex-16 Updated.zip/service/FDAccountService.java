/***
 * class: FDAccountService
 * 
 * Description: Class used to implement FDAccountService
 *
 * Date:06.10.2020
 * 
*/

package com.training.account.service;

import java.util.Iterator;
import java.util.List;

import com.training.account.dataaccess.FDAccountDAO;
import com.training.account.dataaccess.FDAccountDAOImpl;
import com.training.account.FDAccount;

/**
 * FDAccountService class used to implement FDAccountService
 * 
**/

public class FDAccountService {
	FDAccountDAO fDAccountDAOImpl;

	public FDAccountService() {

		fDAccountDAOImpl = new FDAccountDAOImpl();
	}
		
		
		/** Display all accounts**/
		public List<FDAccount> getAllFDAccounts() {

			List fDAccountList = fDAccountDAOImpl.getAllFDAccounts();
			Iterator<FDAccount> iterator = fDAccountList.iterator();

			while (iterator.hasNext()) {

				FDAccount fd = iterator.next();

				System.out.println("Account Number: = " + fd.getAccountNumber());
				System.out.println("Accont Holder Name: = " + fd.getAccountHolderName());
				System.out.println("FD Amount: =" + fd.getFixedDepositAmount());
				System.out.println("FD Tenure: =" + fd.getTenure());

			}

			return fDAccountList;

		}
		/** display particular FDAccount using account number**/
		public FDAccount getFDAccountByAccountNo(int accountNumber) {

			FDAccount fd = fDAccountDAOImpl.getFDAccountByAccountNo(accountNumber);

			System.out.println("Account Number: = " + fd.getAccountNumber());
			System.out.println("Accont Holder Name: = " + fd.getAccountHolderName());
			System.out.println("FD Amount: =" + fd.getFixedDepositAmount());
			System.out.println("FD Tenure: =" + fd.getTenure());
			

			return fd;

		}
		/* deleteFDAccount method is for deleting a particular FDAccount*/
		public void deleteFDAccount(int accountNumber) {

			fDAccountDAOImpl.deleteFDAccount(accountNumber);

		}

	
}
