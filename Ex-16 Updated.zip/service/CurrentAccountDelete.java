/***
 * class: CurrentAccountDelete
 * 
 * Description: CurrentAccountDelete class used to delete and print for CurrentAccount
 *
 * Date:06.10.2020
 * 
 **/

package com.training.account.service;

public class CurrentAccountDelete {

	public static void main(String[] args) {
		CurrentAccountService service =  new CurrentAccountService();
		
		System.out.println("Current Account retrieved successfully");
		
		service.getAllCurrentAccounts();
				
		service.deleteCurrentAccount(100);
		
		System.out.println("----------------------------");
		System.out.println("After deletion");
		
		service.getAllCurrentAccounts();
	}
}
