/***
 * class: LoanAccountDelete
 * 
 * Description: LoanAccountDelete class used to delete and print for LoanAccount
 *
 * Date:06.10.2020
 * 
 **/

package com.training.account.service;

public class LoanAccountDelete {

	public static void main(String[] args) {
		LoanAccountService service =  new LoanAccountService();
		
		System.out.println("Loan Account retrieved successfully");
		
		service.getAllLoanAccounts();
				
		service.deleteLoanAccount(100);
		
		System.out.println("----------------------------");
		System.out.println("After deletion");
		
		service.getAllLoanAccounts();
	}
}
