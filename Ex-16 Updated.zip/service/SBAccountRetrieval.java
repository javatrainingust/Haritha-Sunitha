/**
 * class: SBAccountRetrieval
 * 
 * Description: SBAccountRetrieval class used to print specific accounts for SBAccount
 *
 * Date:06.10.2020
 * 
**/

package com.training.account.service;

/** SBAccountRetrieval class used to print specific accounts for SBAccount **/

public class SBAccountRetrieval  {
	
	public static void main(String[] args) {
		 SBAccountService service =  new  SBAccountService();
		
		
		/** Retrieving all SBAccounts **/
		
		service.getAllSBAccounts();
		
		service.getSBAccountByAccountNo(100);

	}

	
}
