/***
 * ClassName:Guitar
 * 
 * Description: Pojo for Guitar
 * 
 * Date:12-10-2020
 * 
 */

package com.training.account.spring2;

/***
*
* Class Implementing instrument
*
*/

public class Guitar implements Instrument {

	/***
	 * Play method displays Playing Guitar
	 */
	
	public void play() {
		// TODO Auto-generated method stub
		
		System.out.println("Guitar Tone...");
	}

}
