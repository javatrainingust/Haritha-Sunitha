/***
 * ClassName:OneManBandDemo
 * 
 * Description:Main method class,OnemanBand operations like perform starts here
 * 
 * Date:12-10-2020
 * 
 */

package com.training.account.spring2;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/***
 * 
 * class Contains Main
 */


public class OneManBandSample {

	/***
	 * 
	 * 
	 * Assigning the object of onemanband  using getbean
	 * 
	 * 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("instrumentContext.xml");
		
		OneManBand ob = applicationContext.getBean("OneManBand",OneManBand.class);
		
		ob.perform();

	}

}
