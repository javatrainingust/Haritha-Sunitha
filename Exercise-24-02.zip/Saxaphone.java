/***
 * ClassName: Saxaphone
 * 
 * Description:Pojo class for Saxaphone
 * 
 * Date-12-10-2020
 * 
 */

package com.training.account.spring2;

/***
 *
 * Class Implementing instrument and overriding the play method in instrument
 *
 */


public class Saxaphone implements Instrument {

	public void play() {
	
	
		System.out.println("Saxaphone tone...");
		
		
		
	}

}
