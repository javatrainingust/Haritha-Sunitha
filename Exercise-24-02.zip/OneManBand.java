/***
 * ClassName:OneManBand
 * 
 * Description:Operations for one band
 * 
 * Date:12-10-2020
 * 
 */



package com.training.account.spring2;

import java.util.Iterator;
import java.util.List;

/**
 * 
 *This Class implements the performer interface and override the perform 
 *
 *
 **/

public class OneManBand implements Performer {

	
	List<Instrument> instruments;

	
	
	public List<Instrument> getInstruments() {
		return instruments;
	}

	public void setInstruments(List<Instrument> instruments) {
		this.instruments = instruments;
	}

	
	/***
	 * Perform iteration through the Instrument list
	 */
	
	public void perform() {
		// TODO Auto-generated method stub
		

		Iterator it = instruments.iterator();
		
		while(it.hasNext())
		{
			
			Instrument instrumentsList =(Instrument) it.next();
		
			instrumentsList.play();

		}
		
	
		
		
	
		}
		
	
}
