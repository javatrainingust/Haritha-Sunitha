/***
 * ClassName:Flute
 * 
 * Description: Class Implementing instrument
 * 
 * Date:12-10-2020
 * 
 */
package com.training.account.spring2;
/***
*
* Class Implementing instrument
*
*/
public class Flute implements Instrument {
	
	public void play() {
		
		// TODO Auto-generated method stub
		System.out.println("Flute Tone...");
	
	}

}
